package j08_Loops.Loop01_ForLoop;

public class C03_ForLoop {
    public static void main(String[] args) {

    }
}
