package j08_Loops.Loop01_ForLoop;

public class C01_ForLoop {
    public static void main(String[] args) {
        //loop tekrarlayan actionları tanımlayan bloklardır
        //task:41 kere maşallah yazdırın
        for(int a=1 ;a<=41; a++){
            System.out.println(a+ "maşallah");
        }

    }
}
