package j08_Loops.Loop01_ForLoop.Tasks;

import java.util.Scanner;

public class Task03 {
    public static void main(String[] args) {
        //girilen sayının faktöriyelini print eden code
        Scanner scan=new Scanner(System.in);
        System.out.println("bir sayi giriniz:");
        int sayi= scan.nextInt();
    }
}
