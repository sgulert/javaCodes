package j07_StringManipulation;

public class C16_UpperCaseLowerCase {
    public static void main(String[] args) {
        String str="JavaCANlara selam olsun bolcana offer" ;
        System.out.println(str.toLowerCase());
        System.out.println(str.toUpperCase());
    }
}
